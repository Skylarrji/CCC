#Import sys
#The python sys module provides functions and variables which are used to manipulate different parts of the Python Runtime Environment. It lets us access system-specific parameters and functions.
import sys

#Set recursion limit (the amount of times that Python calls a function) to 1 million (since when testing, the program tests 1000*1000, which is 1 million values max, python sets it to 1000 by default)
sys.setrecursionlimit(1_000_000)

#sys.stdin.readline is similar to an input statement
#https://www.geeksforgeeks.org/difference-between-input-and-sys-stdin-readline/

rows = int(sys.stdin.readline())  # No. of rows (as an integer)
columns = int(sys.stdin.readline())  # No. of columns (as an integer)

#Visited squares set: We only need one visited set because if the square has been visited we know there's no way that square will take us to the end. This way, we don't look through the same path multiple times.
#https://www.w3schools.com/python/python_sets.asp

#Empty set format
visited = set()

#Squares to be stored in the following way: {valueOfSquare: [productOfCoords...]}

#https://stackoverflow.com/questions/9197324/what-is-the-meaning-of-curly-braces

#Squares dictionary (form of term: definition, basically assigning square values to their coordinate product)
squares = {}

for i in range(rows):
  #https://www.w3schools.com/python/ref_func_list.asp
    values = list(
      #Takes input values and maps them into the list "values"
      #map is basically a more efficient for-loop
      #https://realpython.com/python-map-function/#getting-started-with-pythons-map
        map(int, sys.stdin.readline().split())
    )  # Split input values (square values) by a space and convert values to an integer

    #Basically enumerate takes the value that was inputted as well as its index number in the variables called index and value
    #https://realpython.com/python-enumerate/#using-pythons-enumerate
    for index, value in enumerate(values):  # Add squares to the squares dictionary

    #Index is basically the same as colomns since it works across, the squareValue is the product of the row * colomn
        squareValue = (i + 1) * (index + 1)

        #Adds value and product of coordinates (squarevalue) to squares dictionary. 
        #https://www.geeksforgeeks.org/python-dictionary-setdefault-method/
        squares.setdefault(value, []).append(squareValue)

#The solve() solves the expression/equation of squarevalue
def solve(squareValue):
    # If the value of the square is 1, it can only go to (1, 1).
    # Therefore, we have reached the end.
    #Return true and return false ends the function
    if squareValue == 1:
        return True

    for index in squares.setdefault(squareValue, []):
        if index not in visited:  # If square hasn't been visited
            visited.add(index)  # Add the index value to visited
            if solve(index):  # Solve
                return True

    return False

#If the end results in the same value as rows *colomns, the thing is solved
print("yes" if solve(rows * columns) else "no")